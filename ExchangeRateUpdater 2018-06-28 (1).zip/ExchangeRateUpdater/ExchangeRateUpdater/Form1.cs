﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Windows.Forms;

namespace ExchangeRateUpdater
{
    public partial class Form1 : Form
    {
        public double lastRate = 0;
        public double previouRate = 0;
        public int lastHour = -1;
        public int errorCounter=0;
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            try
            {
                if (GetRealTimeFX() == 0m)//had errros
                {
                }
                else
                {
                }
            }
            catch (Exception er )
            {
            }
            DateTime TimeNow = DateTime.Now;
            if (TimeNow.Hour >= 14 || TimeNow.Hour <= 3 || (int)TimeNow.DayOfWeek == 6 || (int)TimeNow.DayOfWeek == 0)
            {
                timer1.Interval = 300000;
            }
            else
            {
                timer1.Interval = 30000;
            }
            timer1.Start();
        }

        public Decimal GetRealTimeFX()
        {
            LastRun.Text = DateTime.Now.ToString();

            DateTime TimeNow = DateTime.Now;

            //check for robot flag
            string connString = Properties.Settings.Default.ConString;
            SqlConnection sqlConn = new SqlConnection(connString);
            string checkFlagValue = "";
            string checkFlagSQL = "SELECT   TOP (1) SettingValue FROM tbSettings WHERE(SettingName = 'ExchangeRateRobot')";
            using (sqlConn)
            {
                if (sqlConn.State.ToString() != "Open") { sqlConn.Open(); }
                SqlCommand cmdcheckFlag = new SqlCommand(checkFlagSQL, sqlConn);
                checkFlagValue = cmdcheckFlag.ExecuteScalar().ToString();

                sqlConn.Close();
            }
            if (checkFlagValue == "0")
            {
                return -1;
            }

            //String strSQLQuery = "SELECT   CountryID, LastUpdated, LastValue FROM tbExchangeRealTime WHERE(CountryID = 42)";
            //String updateQuery = "UPDATE  tbExchangeRealTime SET LastUpdated = @LastUpdated, LastValue = @LastValue WHERE(CountryID = 42)";

            // DateTime LastUpdated;
            decimal PayoneerFx = 0;


            string SMTPServerAddress = Properties.Settings.Default.SMTPserver;
            string sUserName = Properties.Settings.Default.SMTPuser;
            string sPassord = Properties.Settings.Default.SMTPpass;
            string sMailFrom = Properties.Settings.Default.MailFrom;
            string sMailTo = Properties.Settings.Default.WarningRecipients;
            string sCCTo = Properties.Settings.Default.MailCC;
            string sBBCTo = Properties.Settings.Default.MailBCC;
            decimal dcMarketValue = 0;
            try
            {
                dcMarketValue = XEBRFX();

                PayoneerFx = GeobridgeMethods.gConversions.Round((dcMarketValue * 0.99m), 3);
            }
            catch (Exception e)
            {
                errorTextBox.Text = "XE error (" + (errorCounter + 1).ToString() + "): " + e.Message  + Environment.NewLine + "Last error time: " + DateTime.Now.ToString(); 
                //failed getting rate
                PayoneerFx = 0;
                dcMarketValue = 0;
            }


            if ((dcMarketValue) == 0)
            {
                //error 
                //send mail
                
                //errorCounter = Convert.ToInt32(hadErrorLast.Text);
                if (errorCounter > 0 && (int)DateTime.Now.DayOfWeek > 0 && (int)DateTime.Now.DayOfWeek < 6)
                {
                    if (errorCounter == 2 || (errorCounter % 50) == 0)
                    {
                        string sSubject = "Payonner Exchange Rate Update Error!";
                        string sBody = "Cannot retrieve XE exchange rate" + Environment.NewLine + Environment.NewLine + "Please verify as soon as possible and manually update Payoneer rates";
                        string mailResult = sendEmail(SMTPServerAddress, sUserName, sPassord, sBody, sSubject, sMailFrom, sMailTo, sCCTo, sBBCTo);
                    }
                }
                errorCounter = errorCounter + 1;
               // hadErrorLast.Text = errorCounter.ToString();
            }
            else
            {
                errorCounter = 0;
                LastUpdated.Text = DateTime.Now.ToString();
                LastValue.Text = PayoneerFx.ToString();
                string updateQuery = "UPDATE  tbSpecialExRates  SET ExchangeRate = @NewRate, LastUpdated = GETDATE(), ExchangeRatePb = @NewRate WHERE(AgentID = @AgentID)";
                string historySave = "INSERT INTO tbFXhistory(MarketValue, AgentValue) VALUES(@MarketValue, @AgentValue)";
                sqlConn.ConnectionString = connString;
                using (sqlConn)
                {
                    if (sqlConn.State.ToString() != "Open") { sqlConn.Open(); }
                    SqlCommand cmdSetValue = new SqlCommand(updateQuery, sqlConn);
                    cmdSetValue.Parameters.AddWithValue("@NewRate", PayoneerFx);
                    cmdSetValue.Parameters.AddWithValue("@AgentID", 2271);
                    cmdSetValue.ExecuteNonQuery();

                    SqlCommand cmdSaveHistory = new SqlCommand(historySave, sqlConn);
                    cmdSaveHistory.Parameters.AddWithValue("@MarketValue", dcMarketValue);
                    cmdSaveHistory.Parameters.AddWithValue("@AgentValue", PayoneerFx);
                    cmdSaveHistory.ExecuteNonQuery();


                    sqlConn.Close();
                }
            }

            return PayoneerFx;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Start")
            {
                button1.Text = "Stop";
                decimal xxx = GetRealTimeFX();
                timer1.Interval = 30000;
                timer1.Enabled = true;
                timer1.Start();
            }
            else
            {
                button1.Text = "Start";
                timer1.Stop();
                timer1.Enabled = false;
            }
        }

        private String sendEmail(string SMTPServerAddress, string UserName, string Passord, string Body, string Subject, string MailFrom, string MailTo, string CCTo, string BBCTo)
        {
            MailMessage mm = new MailMessage();
            mm.IsBodyHtml = true;
            mm.From = new MailAddress(MailFrom);
            mm.Body = Body;
            mm.Subject = Subject;

            String[] recipients = MailTo.Split(';');
            foreach (string emailRec in recipients)
            {
                mm.To.Add(emailRec.Trim());
            }

            if (CCTo.Length > 0)
            {
                String[] ccRecipients = CCTo.Split(';');

                foreach (string emailRecCC in ccRecipients)
                {
                    mm.Bcc.Add(emailRecCC.Trim());
                }
            }

            //Username: system@pontualmt.net
            //Password: n?B<LBxf
            //Mail server (SMTP): smtpout.secureserver.net

            SmtpClient sm = new SmtpClient(SMTPServerAddress);

            sm.Credentials = new NetworkCredential(UserName, Passord);
            try
            {
                sm.Send(mm);
                return "OK";
            }
            catch (Exception ex)
            {
                return ("FAILURE SENDING MAIL:" + ex.Message + ":::" + DateTime.Now.ToString("MM/dd/yyyy hh.mm.ss tt") + System.Environment.NewLine);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private decimal XEBRFX()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            string userName = Properties.Settings.Default.xeUser;
            string password = Properties.Settings.Default.xePass;

            decimal BRFX = 0;

            string uri = "https://xecdapi.xe.com/v1/convert_from.json/?from=USD&to=BRL&amount=1";

            var webRequest = WebRequest.Create(uri);
            webRequest.Headers["Authorization"] = "Basic " + Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(userName + ":" + password));

            webRequest.Timeout = 5000;

            string URLtext2 = "";
            using (var response = webRequest.GetResponse())
            {
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    URLtext2 = reader.ReadToEnd();
                }
            }

            JsonTextReader reader1 = new JsonTextReader(new StringReader(URLtext2));
            StringBuilder sb = new StringBuilder();
            string propertyName = "";
            string LastFx = "";
            while (reader1.Read())
            {


                if (reader1.Value != null)
                {
                    if (propertyName == "mid")
                    {
                        LastFx = reader1.Value.ToString();
                        break;
                    }
                    if (reader1.TokenType.ToString() == "PropertyName")
                    {
                        propertyName = reader1.Value.ToString();
                    }

                }
                else
                { }

            }
            decimal decMW;
            if (Decimal.TryParse(LastFx, out decMW))
            {
                BRFX = decMW;
            }
            else
            {//try again
            }
            return BRFX;


        }
    }
}