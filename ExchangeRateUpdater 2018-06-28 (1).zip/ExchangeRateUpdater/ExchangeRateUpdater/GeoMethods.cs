﻿using System;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;
using System.Text;
namespace GeobridgeMethods
{
    public static class DateTimeFunctions
    {

        public static string FirstOfNextMonth(DateTime inDate)
        {
            return (new DateTime(inDate.Year, inDate.Month, 1).AddMonths(1)).ToString("d");
        }

        public static string LastOfNextMonth(DateTime inDate)
        {
            return new DateTime(inDate.Year, inDate.Month, 1).AddMonths(2).AddDays(-1).ToString("d");
        }

        public static string FirstOfTheMonth(DateTime inDate)
        {
            return (new DateTime(inDate.Year, inDate.Month, 1)).ToString("d");
        }

        public static string LastOfTheMonth(DateTime inDate)
        {
            return (new DateTime(inDate.Year, inDate.Month, 1).AddMonths(1)).AddDays(-1).ToString("d");
        }

        public static string FirstOfPreviousMonth(DateTime inDate)
        {
            return ((new DateTime(inDate.Year, inDate.Month, 1).AddMonths(-1))).ToString("d");
        }

        public static string LastOfPreviousMonth(DateTime inDate)
        {
            return (new DateTime(inDate.Year, inDate.Month, 1)).AddDays(-1).ToString("d");
        }

        public static string TomorrowDate(DateTime inDate)
        {
            return inDate.AddDays(1).ToString("d");
        }

        public static string FormatYYYYMMDD(DateTime inDate)
        {
            string returnDate = inDate.Year.ToString() + OddFunctions.PadZerosLeft(2, inDate.Month.ToString()) + OddFunctions.PadZerosLeft(2, inDate.Day.ToString());
            return returnDate;
        }

        public static bool ConvertISODateStringToDate(string isoDate, ref DateTime returnDate)
        {
            try
            {
                returnDate = DateTime.Parse(isoDate, null, System.Globalization.DateTimeStyles.RoundtripKind);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static string ConvertDateToISODateString(DateTime theDate)
        {
            DateTimeOffset localTimeAndOffset = new DateTimeOffset(theDate, TimeZoneInfo.Local.GetUtcOffset(theDate));

            return localTimeAndOffset.ToString("yyyy-MM-ddTHH:mm:ssK");
        }
        public static string ConvertDateToShortISODateString(DateTime theDate)
        {
            DateTimeOffset localTimeAndOffset = new DateTimeOffset(theDate, TimeZoneInfo.Local.GetUtcOffset(theDate));

            return localTimeAndOffset.ToString("yyyy-MM-dd");
        }


    }
    public static class OddFunctions
    {

        public static String Num2ExcelColumn(int num)
        {


            int dividend = num;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;

        }
        public static bool IsOdd(int value)
        {
            return value % 2 != 0;
        }

        public static string PadZerosLeft(int NoZeros, string StringToPad)
        {
            int stLenght = StringToPad.Length;
            string strZeros = "000000000000000000000000000000000000";
            try
            {
                strZeros = strZeros.Substring(0, NoZeros - stLenght);
            }
            catch
            {
                strZeros = "";
            }
            return strZeros + StringToPad;
        }

    }

    public static class validations
    {

   

        public static bool checkLength(object obj, int maxLength)
        {
            if (obj.ToString().Length > maxLength)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    public static class gConversions
    {
        public static bool StringToBool(string fromString)
        {
            String StringToCheck = fromString.Trim();

            if (StringToCheck == "true" || StringToCheck == "True" || StringToCheck == "1" || StringToCheck == "-1")
            {
                return true;
            }
            else
                return false;
        }

        public static string CleanNumbers(string NumberString)
        {
            var stripped = Regex.Replace(NumberString, "[^0-9]", "").Trim();
            return stripped;

        }

        public static decimal CleanDecimal(string NumberString)
        {
            decimal convertedNo;
            if (decimal.TryParse(NumberString, out convertedNo) == true)
            {
                return convertedNo;
            }
            return 0;
        }


        public static string CleanStrings(string fromString)
        {
            return Regex.Replace(fromString, @"\s+", " ").Trim();
        }
        public static string Left(this string str, int length)
        {
            return str.Substring(0, Math.Min(length, str.Length));
        }
        public static string Right(this string str, int length)
        {
            try
            {
                return str.Substring(str.Length - length, length);
            }
            catch
            {
                return str;
            }
        }

        public static decimal Round(decimal inNumber, int noOfdigits)
        {
            return Math.Round(inNumber, noOfdigits, MidpointRounding.AwayFromZero);
        }

        public static string CleanAPIString(string fromString)
        {
            StringBuilder ToString = new StringBuilder();
            try
            {

                string strFilter = " ÇüéâäàåçêëèïîíìÄÅÉæÆôöòûùÖÜáíóúñÑÀÁÂÃÈÊËÌÍÎÏÐÒÓÔÕØÙÚÛÝßãðõøýþÿ$abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-,/ @%.()'";

                ToString.Append("");

                char[] LetterArray = fromString.ToCharArray();

                char LastLetter = '+';
                char NewLetter;

                // Loop through array.
                for (int i = 0; i < LetterArray.Length; i++)
                {
                    NewLetter = LetterArray[i];
                    if ((NewLetter.ToString() == "'" || NewLetter.ToString() == " ") && NewLetter == LastLetter)
                    {
                        //remove duplicate double '' or double spaces
                    }
                    else
                    {
                        if (strFilter.IndexOf(LetterArray[i].ToString()) >= 0)
                        {
                            ToString.Append(LetterArray[i].ToString());
                        }

                    }

                    LastLetter = LetterArray[i];

                }
            }
            catch (Exception e)
            {
                string eMessage = e.Message;
            }
            //trim and replace single quote by double single quotes '' for SQL compatibility
            return ToString.ToString().Trim().Replace("'", "''");
        }


    }
}

